const ctx = document.getElementById('matchcount');
const mtc = document.getElementById('conti');
const yso = document.getElementById('yshootout');
const nso = document.getElementById('nshootout');
const linec = document.getElementById('linec');

  
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Friendly', 'FIFA WorldCup Qualifier', 'UEFA Nations League', 'UEFA Euro qualification', 'African Cup of Nations qualification', 'African Cup of Nations','CONCACAF Nations League','AFC Asian Cup qualification','COSAFA Cup','African Nations Championship','Other tournament'],
        datasets: [{
          label: '# of Matches recorded',
          data: [1417,1173,415,262,243,136,126,111,90,80,683],
          backgroundColor:['rgb(0, 239, 80)','rgb(247, 54, 77)','rgb(95, 100, 245)','rgb(95, 100, 245)','rgb(95, 100, 245)','rgb(95, 100, 245)','rgb(95, 100, 245)','rgb(95, 100, 245)','rgb(95, 100, 245)','rgb(95, 100, 245)','rgb(227, 230, 60)'],
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });

    new Chart(mtc, {
        type: 'pie',
        data: {
          labels: ['Europe','Africa','Asia','North America','South America','Oceania'],
          backgroundColor:['rgb(2, 48, 250)',
                            'rgb(15, 179, 0)',
                            'rgb(250, 15, 34)',
                            'rgb(245, 145, 5)',
                            'rgb(189, 5, 245)',
                            'rgb(5, 241, 245)'],
          datasets: [{
            label: '# of Matches in record',
            data: [1660,1163,956,547,320,90],
            
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });

      new Chart(yso, {
        type: 'doughnut',
        data: {
          labels: ['Win','Lose','Draw'],
          backgroundColor:['rgb(5, 242, 36)',
                            'rgb(252, 3, 3)',
                            'rgb(143, 141, 141)'],
          datasets: [{
            label: '# of Matches in record',
            data: [2243,1353,1058],
            
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });

      new Chart(nso, {
        type: 'doughnut',
        data: {
          labels: ['Win','Lose'],
          backgroundColor:['rgb(43, 255, 0)',
                            'rgb(15, 179, 0)'
                            ],
          datasets: [{
            label: '# of Matches in record',
            data: [41,31],
            
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });

        new Chart(arec, {
            type: 'radar',
            data: {
              labels: ['Europe','Africa','Asia','North America','South America','Oceania'],
              
              datasets: [{
                label: 'Wins & Draws  /    Loss',
                data: [1135/525 , 855/308, 673/283, 394/153, 233/87, 62/28 ],
                
                borderWidth: 1
              }]
            },
            options: {
              scales: {
                y: {
                  beginAtZero: true
                }
              }
            }
          });

          new Chart(linec, {
            type: 'line',
            data: {
              labels: ['2017','2018','2019','2020','2021','2022'],
              
              datasets: [{
                label: 'Wins & Draws  /    Loss',
                data: [636/249 , 594/236, 744/331, 200/98, 765/312, 413/158],
                fill: false,

              }]
            },

          });